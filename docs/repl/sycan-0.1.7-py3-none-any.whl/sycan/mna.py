"""MNA infrastructure: component base, stamping context, and solvers.

Two analysis modes are supported:

* ``"dc"`` — steady-state operating point. Inductors short, capacitors open.
  Components with a ``stamp_nonlinear`` hook (e.g. MOSFETs in sub-threshold)
  contribute transcendental terms and the solver falls back to ``cas.solve``.
* ``"ac"`` — small-signal frequency-domain analysis using a Laplace
  variable ``s``. Capacitors stamp admittance ``sC``; inductors stamp
  ``1/(sL)``. Source AC values override DC values.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, ClassVar, Iterator, Optional, Union

from sycan import cas as cas

if TYPE_CHECKING:
    from sycan.circuit import Circuit

Value = Union[cas.Expr, int, float, str]

# Specification accepted by ``Component(include_noise=...)``.
NoiseSpec = Union[None, str, list[str], tuple[str, ...], frozenset[str]]

# Recognised noise kinds. Components advertise the subset they emit via
# ``SUPPORTED_NOISE``.
_NOISE_KINDS: frozenset[str] = frozenset({"thermal", "shot", "flicker"})

# Physical-constant symbols used inside symbolic noise spectral densities.
# Exposed at module level so user code can substitute / numerically
# evaluate them (e.g. ``S.subs({k_B: 1.380649e-23, T: 300})``).
k_B: cas.Symbol = cas.Symbol("k_B", positive=True)
T: cas.Symbol = cas.Symbol("T", positive=True)
q: cas.Symbol = cas.Symbol("q", positive=True)
freq: cas.Symbol = cas.Symbol("freq", positive=True)  # frequency for flicker noise


@dataclass
class NoiseSource:
    """Symbolic small-signal noise current source.

    A unit current with one-sided power spectral density ``psd``
    (units: A²/Hz) flowing from ``n_plus`` to ``n_minus`` internally
    (same convention as :class:`CurrentSource`). ``kind`` is one of
    ``"thermal"``, ``"shot"``, ``"flicker"``; ``name`` is a unique
    string of the form ``"<component>.<kind>[.<tag>]"`` so that callers
    can dis-aggregate the contributions returned by :func:`solve_noise`.
    """

    name: str
    kind: str
    n_plus: str
    n_minus: str
    psd: cas.Expr


@dataclass
class StampContext:
    """Mutable state handed to each component's ``stamp`` method."""

    A: cas.Matrix
    b: cas.Matrix
    node_rows: dict[str, int]
    aux_rows: dict[str, int]
    mode: str = "dc"  # "dc" or "ac"
    s: Optional[cas.Expr] = None  # Laplace variable, set in AC mode
    x: Optional[cas.Matrix] = None  # unknown symbols vector (set for nonlinear pass)
    residuals: Optional[list] = None  # nonlinear residuals (set for nonlinear pass)

    def n(self, node: str) -> int:
        """MNA row of a node name; ``-1`` for ground."""
        try:
            return self.node_rows[node]
        except KeyError:
            raise ValueError(f"unknown node {node!r}") from None

    def aux(self, name: str) -> int:
        """MNA row of a component's auxiliary branch current."""
        try:
            return self.aux_rows[name]
        except KeyError:
            raise ValueError(
                f"component {name!r} has no auxiliary branch current "
                "(not a V/E/H/L-in-DC source?)"
            ) from None


class Component(ABC):
    """Netlist element that can stamp itself into an MNA matrix.

    Subclasses that introduce a branch-current unknown set
    ``has_aux = True``. Subclasses that add transcendental current
    contributions (e.g. MOSFETs) set ``has_nonlinear = True`` and
    implement :meth:`stamp_nonlinear``, which is called during the DC
    residual pass.

    Concrete subclasses declare which of their dataclass fields name
    circuit nodes via ``ports`` — a class variable listing attribute
    names. ``Circuit`` walks this list to register a component's nodes
    without hard-coding per-component attribute names.

    Every concrete subclass is auto-registered into ``Component._registry``
    when its module is imported, keyed by class name. The registry is
    queryable via :meth:`Component.available`.
    """

    name: str
    ports: ClassVar[tuple[str, ...]] = ()
    has_aux: ClassVar[bool] = False
    has_nonlinear: ClassVar[bool] = False
    # Subset of ``_NOISE_KINDS`` this component can emit. Defaults to
    # empty (passive ideal element); concrete classes override.
    SUPPORTED_NOISE: ClassVar[frozenset[str]] = frozenset()

    _registry: ClassVar[dict[str, type["Component"]]] = {}

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)
        # Skip private / abstract bases (leading underscore by convention).
        if cls.__name__.startswith("_"):
            return
        Component._registry[cls.__name__] = cls

    @classmethod
    def available(cls) -> dict[str, type["Component"]]:
        """Return the registry of every concrete Component subclass."""
        return dict(cls._registry)

    def iter_node_names(self) -> Iterator[str]:
        """Yield each circuit node name referenced by this component."""
        for attr in self.ports:
            node = getattr(self, attr, None)
            if node is not None:
                yield node

    def aux_count(self, mode: str) -> int:
        """Number of auxiliary branch currents the component needs in ``mode``."""
        return int(self.has_aux)

    @classmethod
    def _normalize_noise(cls, spec: NoiseSpec) -> frozenset[str]:
        """Validate and canonicalise an ``include_noise=`` argument.

        ``None`` and the empty list disable noise. The string ``"all"``
        expands to whatever ``cls.SUPPORTED_NOISE`` advertises. A single
        kind string or an iterable of kind strings selects those kinds;
        each must be a recognised kind (``"thermal"``, ``"shot"``,
        ``"flicker"``) and supported by the concrete class — otherwise
        a :class:`ValueError` is raised so that user mistakes surface
        early.
        """
        if spec is None:
            return frozenset()
        if isinstance(spec, str):
            if spec == "all":
                return frozenset(cls.SUPPORTED_NOISE)
            requested = frozenset({spec})
        else:
            requested = frozenset(spec)
        invalid = requested - _NOISE_KINDS
        if invalid:
            raise ValueError(
                f"{cls.__name__}: unrecognised noise kinds {sorted(invalid)!r}; "
                f"valid kinds are {sorted(_NOISE_KINDS)!r}"
            )
        unsupported = requested - cls.SUPPORTED_NOISE
        if unsupported:
            raise ValueError(
                f"{cls.__name__}: does not model {sorted(unsupported)!r} "
                f"noise (supported: {sorted(cls.SUPPORTED_NOISE)!r})"
            )
        return requested

    def noise_sources(self) -> list["NoiseSource"]:
        """Return the small-signal noise sources this component emits.

        Default is no-op; concrete components override to emit thermal
        / shot / flicker contributions weighted by the
        :attr:`include_noise` selection.
        """
        return []

    @abstractmethod
    def stamp(self, ctx: StampContext) -> None: ...

    def stamp_nonlinear(self, ctx: StampContext) -> None:
        """Add transcendental terms to ``ctx.residuals`` at solve time.

        Only invoked for DC analysis when the circuit contains at least
        one component with ``has_nonlinear = True``. Default is no-op.
        """
        return None


def build_mna(
    circuit: "Circuit",
    mode: str = "dc",
    s: Optional[cas.Expr] = None,
) -> tuple[cas.Matrix, cas.Matrix, cas.Matrix]:
    """Assemble the linear symbolic MNA system ``A * x = b`` for ``mode``."""
    if mode == "ac" and s is None:
        s = cas.Symbol("s")

    nodes = circuit.nodes
    n = len(nodes)
    flat = circuit.flat_components()
    aux_owners = [c for c in flat if c.aux_count(mode) > 0]
    m = len(aux_owners)

    A = cas.zeros(n + m, n + m)
    b = cas.zeros(n + m, 1)
    node_rows = {name: idx - 1 for name, idx in circuit._nodes.items()}
    aux_rows = {c.name: n + k for k, c in enumerate(aux_owners)}

    # Resolve mutual coupling: look up inductor values from the flat list
    # so that MutualCoupling.stamp() can compute M_ij = k·sqrt(L_i·L_j).
    for c in flat:
        from sycan.components.basic.mutual_coupling import MutualCoupling
        if isinstance(c, MutualCoupling):
            c.resolve(flat)

    ctx = StampContext(
        A=A, b=b, node_rows=node_rows, aux_rows=aux_rows, mode=mode, s=s
    )
    for c in flat:
        c.stamp(ctx)

    x = cas.Matrix(
        [cas.Symbol(f"V({nm})") for nm in nodes]
        + [cas.Symbol(f"I({c.name})") for c in aux_owners]
    )
    return A, x, b


def build_residuals(
    circuit: "Circuit",
    mode: str = "dc",
    s: Optional[cas.Expr] = None,
) -> tuple[cas.Matrix, list[cas.Expr]]:
    """Assemble the full residual vector ``A*x - b + nonlinear(x)``.

    Useful as a starting point for custom nonlinear solvers (numerical
    Newton, continuation, noise sampling, etc.) that want the raw
    symbolic equations rather than the dict form produced by
    :func:`solve_dc`.
    """
    A, x, b = build_mna(circuit, mode=mode, s=s)
    residuals = list(A * x - b)

    nodes = circuit.nodes
    n = len(nodes)
    flat = circuit.flat_components()
    aux_owners = [c for c in flat if c.aux_count(mode) > 0]
    node_rows = {name: idx - 1 for name, idx in circuit._nodes.items()}
    aux_rows = {c.name: n + k for k, c in enumerate(aux_owners)}
    ctx = StampContext(
        A=A, b=b, node_rows=node_rows, aux_rows=aux_rows,
        mode=mode, s=s, x=x, residuals=residuals,
    )
    for c in flat:
        if c.has_nonlinear:
            c.stamp_nonlinear(ctx)
    return x, residuals


def solve_dc(circuit: "Circuit", simplify: bool = True) -> dict[cas.Symbol, cas.Expr]:
    """Solve the DC operating point symbolically.

    If any component reports ``has_nonlinear``, the solver builds
    ``residuals = A·x − b`` plus nonlinear contributions and calls
    :func:`sympy.solve`. Otherwise, LU on the linear system.
    """
    A, x, b = build_mna(circuit, mode="dc")
    flat = circuit.flat_components()
    nonlinear = [c for c in flat if c.has_nonlinear]

    if not nonlinear:
        sol = A.LUsolve(b)
        result = {sym: expr for sym, expr in zip(x, sol)}
    else:
        residuals = list(A * x - b)
        nodes = circuit.nodes
        aux_owners = [c for c in flat if c.aux_count("dc") > 0]
        node_rows = {name: idx - 1 for name, idx in circuit._nodes.items()}
        aux_rows = {c.name: len(nodes) + k for k, c in enumerate(aux_owners)}
        ctx = StampContext(
            A=A,
            b=b,
            node_rows=node_rows,
            aux_rows=aux_rows,
            mode="dc",
            x=x,
            residuals=residuals,
        )
        for c in nonlinear:
            c.stamp_nonlinear(ctx)

        # ``cas.solve`` works well for polynomial nonlinear systems
        # (e.g. plain Shichman-Hodges Level-1 in saturation) and even
        # for transcendental ones once the voltage sources have
        # pinned the unknowns down to single equations
        # (e.g. the subthreshold-MOSFET tests). It *spins forever*,
        # though, on segmented systems where the unknowns are
        # genuinely coupled and a ``Piecewise`` selector picks
        # different branches based on those unknowns — that's the
        # MOSFET_3T inverter case. Detect that combination
        # ("residuals contain Piecewise" AND "no free parameters
        # left to solve symbolically over") and skip straight to
        # damped Newton; everything else still goes through the
        # closed-form symbolic path.
        free_params = set()
        for r in residuals:
            free_params |= r.free_symbols
        free_params -= set(x)
        # Use atoms(class) rather than .has(class) — the latter is
        # sympy-only; ``atoms`` works on every CAS backend.
        has_piecewise = any(bool(r.atoms(cas.Piecewise)) for r in residuals)
        try:
            if has_piecewise and not free_params:
                solutions = []
            else:
                solutions = cas.solve(residuals, list(x), dict=True)
        except NotImplementedError:
            solutions = []
        if solutions:
            sol_dict = solutions[0]
            result = {sym: sol_dict.get(sym, sym) for sym in x}
        else:
            # Damped Newton over a numpy-lambdified residual. Plain
            # ``cas.nsolve`` (mpmath's undamped Newton) hangs on
            # MOSFET-style segmented models: when an iterate briefly
            # leaves the physical V_DS ≥ 0 envelope the L1 triode
            # quadratic blows up and Newton can't recover. Damping
            # with line search keeps every step inside the basin
            # of attraction. We also add the standard SPICE GMIN
            # shunt (1 GΩ from every node to ground) so the Jacobian
            # stays conditioned at flat-slope operating points such
            # as L1 saturation with ``lam = 0``.
            import numpy as np
            G_MIN = cas.Float("1e-12")
            reg_residuals = list(residuals)
            for _name, row_idx in node_rows.items():
                reg_residuals[row_idx] += G_MIN * x[row_idx]
            x_list = list(x)
            F_fn = cas.lambdify(
                [x_list], cas.Matrix(reg_residuals), modules="numpy",
            )
            J_fn = cas.lambdify(
                [x_list], cas.Matrix(reg_residuals).jacobian(cas.Matrix(x_list)),
                modules="numpy",
            )
            xv = np.zeros(len(x_list), dtype=float)
            ok = False
            # Line-search trial points routinely probe transcendental
            # branches that overflow ``exp`` — we catch the overflowed
            # iterates via the ``isfinite`` guard below, so the warnings
            # are noise. Suppress them locally instead of letting them
            # leak into the user's output.
            with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
                for _ in range(80):
                    fv = np.asarray(F_fn(xv), dtype=float).reshape(-1)
                    fnorm = float(np.linalg.norm(fv, np.inf))
                    if fnorm < 1e-10:
                        ok = True
                        break
                    Jm = np.asarray(J_fn(xv), dtype=float)
                    # Regularise rank-deficient Jacobians (e.g. a fully
                    # cut-off device makes a row all zeros).
                    Jm = Jm + 1e-12 * np.eye(len(x_list))
                    try:
                        step = np.linalg.solve(Jm, fv)
                    except np.linalg.LinAlgError:
                        step = np.linalg.lstsq(Jm, fv, rcond=None)[0]
                    # Backtracking line search: shrink the step until
                    # the residual norm strictly decreases (or we
                    # exhaust halvings, in which case we accept the
                    # smallest step and try again).
                    alpha = 1.0
                    accepted = False
                    for _ls in range(40):
                        xv_try = xv - alpha * step
                        fv_try = np.asarray(F_fn(xv_try), dtype=float).reshape(-1)
                        if (np.all(np.isfinite(fv_try))
                                and float(np.linalg.norm(fv_try)) < float(np.linalg.norm(fv))):
                            xv = xv_try
                            accepted = True
                            break
                        alpha *= 0.5
                    if not accepted:
                        # Take the tiniest step we tried and continue —
                        # better than spinning at the same iterate.
                        xv = xv - alpha * step
            if not ok:
                raise RuntimeError(
                    "DC solver could not close the nonlinear system. "
                    "Try pinning more node voltages or substituting "
                    "numeric values."
                )
            result = {sym: cas.Float(float(xv[i])) for i, sym in enumerate(x_list)}

    if simplify:
        result = {sym: cas.simplify(expr) for sym, expr in result.items()}
    return result


def solve_impedance(
    circuit: "Circuit",
    port_name: str,
    termination: str = "auto",
    s: Optional[cas.Expr] = None,
    simplify: bool = False,
) -> cas.Expr:
    """Small-signal impedance looking into a named ``Port``.

    A unit AC voltage is applied across the target port and the
    resulting branch current is read out; ``Z = dv/di`` follows.
    Other ports in the netlist are terminated per ``termination``:

    * ``"z"``    — all other ports open (Z-parameter convention).
    * ``"y"``    — all other ports shorted (Y-parameter convention).
    * ``"auto"`` — other *input* ports shorted, *output* ports opened
      (the usual "sources zeroed, loads open" convention for amplifier
      input / output impedance).

    The test source and any termination wires are added to a throw-away
    copy of the circuit, so the caller's circuit is left untouched.
    """
    from sycan.circuit import Circuit
    from sycan.components.basic.port import Port

    if termination not in ("z", "y", "auto"):
        raise ValueError(
            f"termination must be 'z', 'y' or 'auto'; got {termination!r}"
        )

    target_port: Optional[Port] = None
    other_ports: list[Port] = []
    for c in circuit.components:
        if isinstance(c, Port):
            if c.name == port_name:
                target_port = c
            else:
                other_ports.append(c)
    if target_port is None:
        raise ValueError(f"port {port_name!r} not found in circuit")

    # Shallow-copy the circuit: share non-Port components, copy node registry.
    test_circuit = Circuit()
    test_circuit._nodes = dict(circuit._nodes)
    test_circuit.components = [
        c for c in circuit.components if not isinstance(c, Port)
    ]

    # Apply a 1 V AC test source at the target port.
    test_circuit.add_vsource(
        "_Vtest", target_port.n_plus, target_port.n_minus,
        value=0, ac_value=1,
    )

    # Terminate the other ports.
    for p in other_ports:
        short_it = (
            termination == "y"
            or (termination == "auto" and p.role == "input")
        )
        if short_it:
            test_circuit.add_vsource(
                f"_Vshort_{p.name}", p.n_plus, p.n_minus, 0,
            )
        # "z" and "auto" on output/generic ports leave the node open.

    sol = solve_ac(test_circuit, s=s, simplify=False)

    I_test = sol[cas.Symbol("I(_Vtest)")]
    # V_test = +1 (AC); I(V_test) is the SPICE branch current from + to -
    # through the source, which equals the negative of the current the
    # source supplies into the circuit. Hence Z = 1 / (-I_test) = -1/I_test.
    Z = -1 / I_test
    if simplify:
        Z = cas.simplify(Z)
    return Z


def solve_ac(
    circuit: "Circuit",
    s: Optional[cas.Expr] = None,
    simplify: bool = False,
) -> dict[cas.Symbol, cas.Expr]:
    """Solve the small-signal AC response in the Laplace domain.

    Nonlinear components (e.g. MOSFETs) contribute no small-signal model
    yet and are treated as zero-current elements.
    """
    if s is None:
        s = cas.Symbol("s")
    A, x, b = build_mna(circuit, mode="ac", s=s)
    sol = A.LUsolve(b)
    result = {sym: expr for sym, expr in zip(x, sol)}
    if simplify:
        result = {sym: cas.simplify(expr) for sym, expr in result.items()}
    return result


def solve_noise(
    circuit: "Circuit",
    output_node: str,
    s: Optional[cas.Expr] = None,
    simplify: bool = False,
) -> tuple[cas.Expr, dict[str, cas.Expr]]:
    """Output-voltage noise PSD at ``output_node`` in the Laplace domain.

    Walks every component, asks for its :meth:`Component.noise_sources`,
    and superposes their contributions::

        S_V_out(s) = Σ_k  H_k(s) · H_k(-s) · S_k

    where ``H_k(s) = V(output_node) / I_k(s)`` is the trans-impedance
    from the unit-current k-th noise source to the output, and
    ``S_k(s)`` is the source's spectral density. To turn the symbolic
    result into a frequency-domain PSD, substitute ``s = cas.I * omega``.

    Independent V/I sources elsewhere in the circuit are *not* zeroed
    explicitly — their small-signal contribution does not enter the
    transfer-function matrix ``A``, only the right-hand side, and we
    rebuild ``b`` per noise source so they fall away naturally.

    Returns ``(total_psd, per_source_psd)`` where ``per_source_psd``
    maps each :attr:`NoiseSource.name` to its individual contribution.
    """
    if s is None:
        s = cas.Symbol("s")
    A, _x, _b = build_mna(circuit, mode="ac", s=s)
    nodes = circuit.nodes
    if output_node not in nodes:
        raise ValueError(
            f"output node {output_node!r} not in circuit nodes {nodes!r}"
        )
    out_idx = nodes.index(output_node)

    contributions: dict[str, cas.Expr] = {}
    total: cas.Expr = cas.S.Zero
    for c in circuit.flat_components():
        for src in c.noise_sources():
            for endpoint in (src.n_plus, src.n_minus):
                if endpoint not in circuit._nodes:
                    raise ValueError(
                        f"noise source {src.name!r}: node {endpoint!r} not "
                        "registered in circuit"
                    )
            b = cas.zeros(A.shape[0], 1)
            ip = circuit._nodes[src.n_plus] - 1
            im = circuit._nodes[src.n_minus] - 1
            if ip >= 0:
                b[ip] -= 1
            if im >= 0:
                b[im] += 1
            sol = A.LUsolve(b)
            H = sol[out_idx]
            H_sq = H * H.subs(s, -s)
            contrib = H_sq * src.psd
            contributions[src.name] = contrib
            total = total + contrib

    if simplify:
        total = cas.simplify(total)
        contributions = {k: cas.simplify(v) for k, v in contributions.items()}
    return total, contributions


@dataclass
class PZResult:
    """Result of a pole-zero analysis.

    Attributes
    ----------
    H
        Transfer function ``H(s) = V(out) / V(in)`` in the Laplace domain.
    poles
        List of pole locations (roots of the denominator of ``H(s)``).
        Each pole is an expression in component parameters and ``s``.
    zeros
        List of zero locations (roots of the numerator of ``H(s)``).
    numerator
        The raw numerator polynomial / expression of ``H(s)``.
    denominator
        The raw denominator polynomial / expression of ``H(s)``.
    """
    H: cas.Expr
    poles: list[cas.Expr]
    zeros: list[cas.Expr]
    numerator: cas.Expr
    denominator: cas.Expr


def solve_pz(
    circuit: "Circuit",
    output_node: str,
    input_source: Optional[str] = None,
    s: Optional[cas.Expr] = None,
    simplify: bool = False,
) -> PZResult:
    """Pole-zero analysis of a transfer function in the Laplace domain.

    Builds the AC MNA system, extracts the transfer function
    ``H(s) = V(output_node) / source_value``, then factors it to find
    poles (roots of denominator) and zeros (roots of numerator).

    If ``input_source`` is ``None`` (default), the system poles are
    extracted from the source-to-output transfer function using the
    first AC source found in the circuit. If no AC source is present,
    a :class:`ValueError` is raised.

    Parameters
    ----------
    circuit
        The circuit under analysis.
    output_node
        Name of the node whose voltage constitutes the output.
    input_source
        Name of the independent source that drives the input.  If
        ``None``, the first source with a non-zero ``ac_value`` is used.
    s
        Laplace variable.  If ``None``, ``cas.Symbol("s")`` is created.
    simplify
        If ``True``, simplify the transfer function and pole/zero
        expressions.

    Returns
    -------
    PZResult
        Dataclass holding the transfer function, poles, zeros, and
        raw numerator / denominator.
    """
    if s is None:
        s = cas.Symbol("s")

    sol = solve_ac(circuit, s=s, simplify=False)

    nodes = circuit.nodes
    if output_node not in nodes:
        raise ValueError(
            f"output node {output_node!r} not in circuit nodes {nodes!r}"
        )

    v_out = sol[cas.Symbol(f"V({output_node})")]

    # Determine the source value to divide out.
    if input_source is not None:
        src_symbol = cas.Symbol(f"Vin_{input_source}")
        # The source's AC value is in the symbolic expression. We need
        # to find it by looking at the source's ac_value.
        found = None
        for c in circuit.components:
            if c.name == input_source:
                from sycan.components.basic.voltage_source import VoltageSource
                from sycan.components.basic.current_source import CurrentSource
                if isinstance(c, (VoltageSource, CurrentSource)):
                    found = c.ac_value
                break
        if found is None:
            raise ValueError(
                f"source {input_source!r} not found or has no ac_value"
            )
        src_val = cas.sympify(found)
    else:
        # Auto-detect: find the first source with a non-zero ac_value.
        from sycan.components.basic.voltage_source import VoltageSource
        from sycan.components.basic.current_source import CurrentSource
        src_val = None
        for c in circuit.components:
            if isinstance(c, (VoltageSource, CurrentSource)):
                ac = cas.sympify(c.ac_value) if c.ac_value is not None else None
                if ac is not None and ac != 0:
                    src_val = ac
                    break
        if src_val is None:
            raise ValueError(
                "no AC source found in circuit; specify input_source or "
                "add a source with a non-zero ac_value"
            )

    # Transfer function H(s) = V(out) / source_value
    H = v_out / src_val

    if simplify:
        H = cas.simplify(H)

    # Combine into a single rational expression, then separate numerator
    # and denominator.
    H_together = cas.together(H)
    num, den = cas.fraction(H_together)

    if simplify:
        num = cas.simplify(num)
        den = cas.simplify(den)

    # Find roots of numerator (zeros) and denominator (poles).
    # For symbolic circuits, these will be expressions involving
    # component parameters. For numeric circuits, they will be numbers.
    try:
        zero_solutions = cas.solve(num, s, dict=False)
    except (NotImplementedError, Exception):
        zero_solutions = []

    try:
        pole_solutions = cas.solve(den, s, dict=False)
    except (NotImplementedError, Exception):
        pole_solutions = []

    return PZResult(
        H=H,
        poles=list(pole_solutions),
        zeros=list(zero_solutions),
        numerator=num,
        denominator=den,
    )


def solve_dc_sweep(
    circuit: "Circuit",
    parameter: Union[str, cas.Symbol],
    values: list,
    simplify: bool = False,
) -> list[dict[cas.Symbol, cas.Expr]]:
    """Sweep one symbolic parameter across ``values`` and return per-point DC.

    Solves the symbolic DC operating point *once* (with ``simplify``
    deferred to the caller — keep it ``False`` to amortise the symbolic
    cost) and substitutes ``parameter`` with each value in ``values``.
    This is the closed-form analogue of SPICE's ``.DC vsweep`` and is
    useful for plotting transfer characteristics, bias curves, or
    swept-supply gain.

    Parameters
    ----------
    circuit
        Circuit under analysis.
    parameter
        Symbol (or its string name) to sweep. Must appear in the
        symbolic DC solution.
    values
        Iterable of values (numeric or symbolic) to substitute.
    simplify
        If ``True``, simplify the substituted expressions per step.

    Returns
    -------
    list[dict[Symbol, Expr]]
        One dict per swept value, each with the same shape as
        :func:`solve_dc`'s return value but with ``parameter`` replaced.
    """
    if isinstance(parameter, str):
        parameter = cas.Symbol(parameter)

    base = solve_dc(circuit, simplify=False)
    out: list[dict[cas.Symbol, cas.Expr]] = []
    for v in values:
        v_sym = cas.sympify(v)
        step = {sym: expr.subs(parameter, v_sym) for sym, expr in base.items()}
        if simplify:
            step = {sym: cas.simplify(expr) for sym, expr in step.items()}
        out.append(step)
    return out


def solve_tf(
    circuit: "Circuit",
    output_node: str,
    input_source: Optional[str] = None,
    s: Optional[cas.Expr] = None,
    simplify: bool = False,
) -> dict[str, cas.Expr]:
    """Symbolic small-signal transfer function and summary metrics.

    Returns a dict with the closed-form Laplace-domain transfer function
    ``H(s) = V(output_node) / source_value`` plus convenient summary
    metrics extracted symbolically:

    * ``H``           — full ``H(s)`` expression
    * ``dc_gain``     — ``H(0)`` (i.e. ``H.subs(s, 0)``)
    * ``hf_gain``     — ``lim s→∞ H(s)`` (via ``cas.limit``)
    * ``numerator``   — numerator polynomial of ``H(s)`` (s-domain)
    * ``denominator`` — denominator polynomial of ``H(s)`` (s-domain)

    Source selection follows the same rule as :func:`solve_pz`: if
    ``input_source`` is ``None``, the first source with a non-zero
    ``ac_value`` is used.
    """
    if s is None:
        s = cas.Symbol("s")

    pz = solve_pz(
        circuit,
        output_node=output_node,
        input_source=input_source,
        s=s,
        simplify=simplify,
    )
    H = pz.H

    try:
        dc_gain = cas.simplify(H.subs(s, 0))
    except Exception:
        dc_gain = H.subs(s, 0)

    try:
        hf_gain = cas.limit(H, s, cas.oo)
    except Exception:
        hf_gain = None

    return {
        "H": H,
        "dc_gain": dc_gain,
        "hf_gain": hf_gain,
        "numerator": pz.numerator,
        "denominator": pz.denominator,
    }


def solve_sensitivity(
    circuit: "Circuit",
    output: Union[str, cas.Symbol],
    parameters: Optional[list] = None,
    mode: str = "dc",
    s: Optional[cas.Expr] = None,
    normalized: bool = False,
    simplify: bool = False,
) -> dict[cas.Symbol, cas.Expr]:
    """Symbolic small-signal sensitivity ``∂V(out)/∂p`` per parameter.

    Solves the requested analysis (``"dc"`` or ``"ac"``) symbolically,
    extracts the output expression for ``output`` (a node name or a
    symbol such as ``Symbol("V(out)")``), and differentiates w.r.t.
    each parameter.

    Parameters
    ----------
    circuit
        Circuit under analysis.
    output
        Node name (string) or unknown symbol (e.g. ``Symbol("I(V1)")``).
    parameters
        List of symbols (or names) to differentiate over. ``None`` means
        every free symbol of the output expression that is not an
        unknown of the MNA system.
    mode
        ``"dc"`` (default) or ``"ac"``.
    s
        Laplace variable for AC mode.
    normalized
        If ``True``, return the relative sensitivity
        ``(p / V_out) · ∂V_out/∂p``, which is dimensionless and matches
        the SPICE ``.SENS`` convention for "% per %".
    simplify
        Apply :func:`cas.simplify` to each sensitivity expression.

    Returns
    -------
    dict[Symbol, Expr]
        Mapping of each parameter symbol to its sensitivity expression.
    """
    if mode == "dc":
        sol = solve_dc(circuit, simplify=False)
    elif mode == "ac":
        sol = solve_ac(circuit, s=s, simplify=False)
    else:
        raise ValueError(f"mode must be 'dc' or 'ac'; got {mode!r}")

    if isinstance(output, str):
        out_sym = cas.Symbol(f"V({output})")
    else:
        out_sym = output
    if out_sym not in sol:
        raise ValueError(
            f"output {out_sym!r} not in solution; available: {list(sol)!r}"
        )
    expr = sol[out_sym]

    if parameters is None:
        unknowns = set(sol.keys())
        params: list[cas.Symbol] = sorted(
            (sym for sym in expr.free_symbols if sym not in unknowns),
            key=lambda x: str(x),
        )
    else:
        params = [
            cas.Symbol(p) if isinstance(p, str) else p for p in parameters
        ]

    out: dict[cas.Symbol, cas.Expr] = {}
    for p in params:
        d = cas.diff(expr, p)
        if normalized:
            d = (p / expr) * d
        if simplify:
            d = cas.simplify(d)
        out[p] = d
    return out
